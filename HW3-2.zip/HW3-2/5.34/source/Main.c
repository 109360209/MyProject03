#include<stdio.h>
#include<stdlib.h>

int power(int base, int exponent);

int main(void)
{ 
	int base, exponent;
	printf("Enter two integer:\n");
	scanf_s("%d%d", &base, &exponent);
	printf("(%d,%d) = %d\n", base, exponent,power(base,exponent));
	system("pause");
	return 0;
}

int power(int base, int exponent)
{
	if (exponent != 1)
	{
		return base * power(base, exponent - 1);
	}
	return base;
}