#include<stdio.h>
#include<stdlib.h>


int main()
{
	char alphabet;

	printf("�п�J�r��:");
	scanf_s("%c", &alphabet);

	if (alphabet >= 'A' && alphabet <= 'Z')
	{
		alphabet = alphabet + 32;
	}

	else if (alphabet >= 'a' && alphabet <= 'z')
	{
		alphabet = alphabet - 32;
	}


	printf("�ഫ��r����:%c\n", alphabet);

	system("pause"); 
	return 0;
}












