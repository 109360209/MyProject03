#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int a, b, s;
	printf("�п�J��Ӿ��:\n");
	scanf_s("%d %d", &a, &b);
	s = a * b;

	while (b != 0)
	{
		int r = a % b;

		a = b;
		 
		b = r;
	}

	printf("LCM�G%d\n", s / a);
	return 0;
}



