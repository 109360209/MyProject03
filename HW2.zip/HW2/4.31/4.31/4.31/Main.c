#include<stdio.h>
#include<stdlib.h>

int main()
{
	int d[10] = { 4,3,2,1,0,1,2,3,4 };
	int h[10] = { 1,3,5,7,9,7,5,3,1 };
	for (int i = 0; i < 9; i++) 
	{
		for (int j = 0; j <= d[i]; j++)
			printf(" ");
		for (int k = 0; k <= (h[i] - 1); k++)
			printf("*");
		puts("");
	}
	system("pause");
	return 0;
}
