#include<stdio.h>
#include<stdlib.h>

int main()
{
	int hours;
	float rate;
	while (1)
	{
		printf("enter # of hours worked(-1 to end):");
		scanf_s("%d", &hours);
		if (hours == -1)
			break;
		printf("enter hourly rate of the worker ($00.00):");
		scanf_s("%f", &rate);
		if (hours > 40)
		{
			printf("salary is: $%.2f\n", rate * 40 + (rate*1.5) * (hours - 40));
		}
		else 
		{
			printf("salary is: $%.2f\n", rate * hours);

		}
		


	}
	system("pause");
	return 0;


}