#include <stdio.h>
#include <stdlib.h>

int main(void)
{	
	int account ;
	float bbalance;
	float nbalance;
	float charges;
	float credits;
	float limits;
	nbalance = 0;
	account = 0;
	
	
	while (account != -1)
	{
		fk:printf("\n");
		printf("Enter account number(-1 to end):");
		scanf_s("%d", &account);
		if (account == -1)
		{
			break;
		}
		printf("Enter beginning balance:");
		scanf_s("%f", &bbalance);
		printf("Enter total charges:");

		scanf_s("%f", &charges);
		printf("Enter total credits:");
		scanf_s("%f", &credits);
		printf("Enter credits limits:");
		scanf_s("%f", &limits);
		nbalance = bbalance + charges - credits;
		if (nbalance < limits)
		{
			goto fk;
		}
		if (nbalance > limits)
		{
			printf("Account:        %d\n", account);
			printf("Credits Limits: %.2f\n", limits);

			printf("Balance:        %.2f\n", nbalance);
			nbalance = bbalance + charges - credits;
			printf("Credits Limits Exceeded\n");
		}
	
	}
	system("pause");
	return 0;

}